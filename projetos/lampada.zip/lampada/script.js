//Styles Area
document.getElementById('titulo').style.textAlign='center'

let lampada = document.getElementById('lampada')
lampada.style.display='block'
lampada.style.margin='0 auto'

let buttonArea = document.getElementById('button_area')

buttonArea.style.textAlign='center'

//Styles Area

function ligar() 
{
    document.getElementById('lampada').src='images/ligada.jpg'
}

function desligar() 
{
    document.getElementById('lampada').src='images/desligada.jpg'
}